# -*- coding: utf-8 -*-

from odoo import models, fields, api
#Adios adios profe.....!!!

# modelo para clientes del gimnasio
class GymClientes(models.Model):
    _name = 'gym.clientes'
    _description = 'clientes del gimnasio'

    nombre = fields.Char(string="Nombre Completo", required=True)
    foto = fields.Binary(string="Fotografia", attachment=True) # almacena la imagen del cliente
    correo = fields.Char(string="Correo Electronico")
    telefono = fields.Char(string="Telefono")
    direccion = fields.Text(string="Direccion")
    fecha_nacimiento = fields.Date(string="Fecha de Nacimiento")
    genero = fields.Selection([
        ('masculino', 'Masculino'),
        ('femenino', 'Femenino'),
        ('otro', 'Otro')
    ], string="Genero")
    fecha_registro = fields.Date(string="Fecha de Registro", default=fields.Date.today)

    # relaciones con otros modelos
    objetivos_ids = fields.One2many('gym.objetivos', 'cliente_id', string="Objetivos")
    progreso_ids = fields.One2many('gym.progreso', 'cliente_id', string="Progreso")
    pagos_ids = fields.One2many('gym.pagos.clases', 'cliente_id', string="Pagos de Clases")
    facturacion_ids = fields.One2many('gym.facturacion', 'cliente_id', string="Facturacion")
    nutricion_ids = fields.One2many('gym.nutricion', 'cliente_id', string="Planes de Nutricion")

    def name_get(self):
        return [(record.id, record.nombre) for record in self]

# modelo para objetivos del cliente
class GymObjetivos(models.Model):
    _name = 'gym.objetivos'
    _description = 'objetivos del cliente'

    nombre = fields.Char(string="Objetivo", required=True)
    descripcion = fields.Text(string="Descripcion")
    cliente_id = fields.Many2one('gym.clientes', string="Cliente")  # relacion con el cliente

    def name_get(self):
        return [(record.id, record.nombre) for record in self]

# modelo para clases
class GymClases(models.Model):
    _name = 'gym.clases'
    _description = 'clases del gimnasio'

    nombre = fields.Char(string="Nombre de la Clase", required=True)
    tipo = fields.Selection([
        ('incluida', 'Incluida en el Bono'),
        ('pago', 'Clase de Pago')
    ], string="Tipo de Clase", required=True)
    precio = fields.Float(string="Precio (si es de pago)")

    def name_get(self):
        result = []
        for record in self:
            result.append((record.id, record.nombre))
        return result

# modelo para disponibilidad semanal
class GymDisponibilidad(models.Model):
    _name = 'gym.disponibilidad'
    _description = 'disponibilidad semanal'

    dias_disponibles = fields.Selection([
        ('lunes', 'Lunes'),
        ('martes', 'Martes'),
        ('miercoles', 'Miercoles'),
        ('jueves', 'Jueves'),
        ('viernes', 'Viernes'),
        ('sabado', 'Sabado'),
        ('domingo', 'Domingo')
    ], string="Dias Disponibles", required=True)

    horarios_preferidos = fields.Char(string="Horarios Preferidos")

    # definicion de campos unicos para cada ejercicio
    ejercicio_1 = fields.Char(string="Nombre del Ejercicio 1")
    rutina_imagen_1 = fields.Binary(string="Imagen de Rutina 1", attachment=True)

    ejercicio_2 = fields.Char(string="Nombre del Ejercicio 2")
    rutina_imagen_2 = fields.Binary(string="Imagen de Rutina 2", attachment=True)

    ejercicio_3 = fields.Char(string="Nombre del Ejercicio 3")
    rutina_imagen_3 = fields.Binary(string="Imagen de Rutina 3", attachment=True)

    ejercicio_4 = fields.Char(string="Nombre del Ejercicio 4")
    rutina_imagen_4 = fields.Binary(string="Imagen de Rutina 4", attachment=True)

# modelo para pagos de clases
class GymPagosClases(models.Model):
    _name = 'gym.pagos.clases'
    _description = 'pagos de clases'

    clase_id = fields.Many2one('gym.clases', string="Clase")
    monto = fields.Float(string="Monto de Pago")
    metodo_pago = fields.Selection([
        ('efectivo', 'Efectivo'),
        ('tarjeta', 'Tarjeta'),
        ('transferencia', 'Transferencia Bancaria')
    ], string="Metodo de Pago")
    cliente_id = fields.Many2one('gym.clientes', string="Cliente")

    @api.onchange('clase_id')
    def _onchange_clase_id(self):
        if self.clase_id and self.clase_id.tipo == 'pago':
            self.monto = self.clase_id.precio
        else:
            self.monto = 0.0

# modelo para el progreso del cliente
class GymProgreso(models.Model):
    _name = 'gym.progreso'
    _description = 'progreso del cliente'

    fecha = fields.Date(string="Fecha", default=fields.Date.today)
    evaluacion_fisica = fields.Text(string="Evaluacion Fisica") # evaluacion fisica del cliente
    comentarios = fields.Text(string="Comentarios")
    cliente_id = fields.Many2one('gym.clientes', string="Cliente")  # relacion con el cliente

    def name_get(self):
        return [(record.id, f"Progreso - {record.fecha}") for record in self]

# modelo para planes de nutricion
class GymNutricion(models.Model):
    _name = 'gym.nutricion'
    _description = 'plan de nutricion'

    plan_alimentacion = fields.Text(string="Plan de Alimentacion")
    recomendaciones = fields.Text(string="Recomendaciones")
    cliente_id = fields.Many2one('gym.clientes', string="Cliente", required=True)

# modelo para pagos y facturacion
class GymFacturacion(models.Model):
    _name = 'gym.facturacion'
    _description = 'pagos y facturacion'

    fecha_pago = fields.Date(string="Fecha de Pago", default=fields.Date.today)
    monto_total = fields.Float(string="Monto Total")
    metodo_pago = fields.Selection([
        ('efectivo', 'Efectivo'),
        ('tarjeta', 'Tarjeta'),
        ('transferencia', 'Transferencia Bancaria')
    ], string="Metodo de Pago")
    cliente_id = fields.Many2one('gym.clientes', string="Cliente", required=True)
