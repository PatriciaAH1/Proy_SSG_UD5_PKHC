# -*- coding: utf-8 -*-
# from odoo import http


# class GymEvaluacionPersonalizadaPkhc2(http.Controller):
#     @http.route('/gym__evaluacion__personalizada__pkhc2/gym__evaluacion__personalizada__pkhc2', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/gym__evaluacion__personalizada__pkhc2/gym__evaluacion__personalizada__pkhc2/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('gym__evaluacion__personalizada__pkhc2.listing', {
#             'root': '/gym__evaluacion__personalizada__pkhc2/gym__evaluacion__personalizada__pkhc2',
#             'objects': http.request.env['gym__evaluacion__personalizada__pkhc2.gym__evaluacion__personalizada__pkhc2'].search([]),
#         })

#     @http.route('/gym__evaluacion__personalizada__pkhc2/gym__evaluacion__personalizada__pkhc2/objects/<model("gym__evaluacion__personalizada__pkhc2.gym__evaluacion__personalizada__pkhc2"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('gym__evaluacion__personalizada__pkhc2.object', {
#             'object': obj
#         })
